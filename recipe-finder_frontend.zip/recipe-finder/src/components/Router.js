import React from 'react'
import {Routes,Route} from 'react-router-dom'
import Search from './Search'
import AddRecipe from './AddRecipe'
import Success from './Success'
import FavouriteRecipe from './FavouriteRecipe'
import RecipeCard from './RecipeCard'


const Router = (props) => {
  const getFavourites=(value)=>{
    console.log("from router"+value)
    props.getFavourites(value)

  }
  return (
    <>
    <Routes>
    <Route path="/" element={<Search getFavourites={getFavourites}/>}></Route>
    
        <Route path="/addRecipe" element={<AddRecipe/>}></Route>
        <Route path="/addRecipe/success" element={<Success/>}></Route>
        <Route path="/favouriteRecipe" element={<FavouriteRecipe/>}></Route>
        {/* <Route path="/favouriteRecipe/RecipeCard" element={<RecipeCard/>}></Route> */}


            
    

        
    </Routes>
    
    
    </>
  )
}

export default Router