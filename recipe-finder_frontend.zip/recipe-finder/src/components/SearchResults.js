import React, { useState } from "react";
import  { useEffect } from "react";

import "../css/SearchResults.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faHeart } from "@fortawesome/free-solid-svg-icons";


const SearchResults = (props) => {
  const[recipes,setRecipes]=useState()
  const[recipeVal,setRecipeVal]=useState([])
  useEffect(()=>{

    setRecipes(props.recipes)
    


  })

  

  // let recipes=props.recipes
  const[viewRecipe,setViewRecipe]=useState("")
  const[viewRecipeStatus,setViewRecipeStatus]=useState(false)
  const [favouriteItem,setFavouriteItem]=useState([])
  let favourite_list_data= window.localStorage.getItem('Favourite_List');
  let favourite_list=[];
  if(favourite_list_data!=null){
     favourite_list=JSON.parse(favourite_list_data)


  }
  useEffect(()=>{
    let favourite_list_data= window.localStorage.getItem('Favourite_List')
    if(favourite_list_data!=null)
    {
      favourite_list=JSON.parse(favourite_list_data)


    }
    else{
      window.localStorage.setItem('Favourite_List',JSON.stringify([]))

    }
    console.log(recipes)
    // setRecipeVal(recipe)
    // props.reciepe_data(e,recipes,true);




   },[recipes])



  const changeFormat = (recipe) => {
    // console.log(recipe)
    let duration = recipe === "" ? "PT0M" : recipe;
    let string = duration;

    let array = string.match(/(\d+)(?=[MHS])/gi) || [];
    // console.log("Array " + array);

    let formatted = array
      .map(function (item) {
        if (item.length < 2 && array.length > 1) return "0" + item;
        if (item.length < 2 && array.length <= 1) return "00:0" + item;
        if (item.length <= 2 && array.length <= 1) return "00:" + item;
        // console.log(recipe);
        return item;
      })
      .join(":");
    // console.log(formatted);
    formatted = formatted == "00:00" ? "N/A" : formatted;
    return formatted;
  };
  const viewRecipeFunc=(e,recipe)=>{
    e.preventDefault();
    console.log("sending recipe to search component"+JSON.stringify(recipe))
    props.reciepe_data(e,recipe,true);
 
  }
  function update(arr, id, updatedData) {
    return arr.map((item) => (item._id === id ? { ...item, ...updatedData } : item))
  }
  const addFavourite=async(e,recipe,indexValue)=>{
    e.preventDefault();
    const index=recipe._id
    console.log("click detail"+e.detail)
    const status=recipe.isFavourite
    console.log(Boolean(status))
    const statusChanged={isFavourite:!Boolean(status)}
    console.log(statusChanged)
    recipe={...recipe,"indexVal":index,"isFavourite":!Boolean(status)}
    console.log(recipe)
   const new_Array= update(recipes,index,statusChanged)
   console.log(new_Array);
   let recipeIndex=recipes.findIndex(obj=>obj._id==index)
   recipes[recipeIndex].isFavourite=!Boolean(status)
    // const newArray=[...recipes,recipe]
    // console.log("new Array"+JSON.stringify(newArray))
     setRecipes(prevstate=>[...prevstate])
    console.log(recipes)
    if(favourite_list &&  !favourite_list.find(item=>item.indexVal==index))
    {
      favourite_list.push(recipe);
      document.querySelector(`.favourite_${indexValue}`).style.color="#e517a4"
    console.log(favourite_list);
    // setFavouriteItem(prevstate => ([...prevstate,recipe]))
    // setFavouriteItem(prevState => [...favourite_list],favourite_list)



    }
    else if(favourite_list && favourite_list.find(item=>item.indexVal==index) ){
      console.log(favourite_list)
      console.log(favourite_list.find(item => item.indexVal))
      console.log("index"+index);
      favourite_list=favourite_list.filter((obj)=>obj.indexVal!==index)
      document.querySelector(`.favourite_${indexValue}`).style.color="black"
    console.log(favourite_list);
    // setFavouriteItem(favourite_list)


    }
    props.getFavourites(favourite_list)

    window.localStorage.setItem('Favourite_List',JSON.stringify(favourite_list))
    const {_id}=recipe
    console.log("id "+_id)
    await fetch(`/api/updateFavouriteRecipe/${_id}`,{method:'POST',headers:{"content-Type":"text/html"}}).then((data)=>{return data.text()}).then((data)=>console.log(data))


    


    





  }




  return (
    <div>

    <ul className="recipes-results">
      {
        recipes && recipes.map((recipe,index) => (
          <li className="recipe-card">
            <img src={recipe.image} onError={(e)=>e.target.src="/silehoutee.png"} ></img>
   
            <h1>{recipe.name}</h1>

            <p>
              <strong>CookTime:</strong>
              {changeFormat(recipe.cookTime)}
            </p>
            <p>
              <strong>PrepTime:</strong>
              {changeFormat(recipe.prepTime)}
            </p>
            <p>
              <strong>Yield:</strong>
              {recipe.recipeYield}
            </p>
            <div className="flex-buttons">
            <button onClick={(e)=>viewRecipeFunc(e,recipe)}>
                <span>
                  <FontAwesomeIcon icon={faEye} />
                </span>

                <span> View Recipe</span>
                
              </button>
              <button onClick={(e)=>addFavourite(e,recipe,index)}>
                <span    className={`favourite_${index}`} style={recipe.isFavourite?{color:"#e517a4"}:{color:"black"}}>
                  <FontAwesomeIcon icon={faHeart} />
                </span>
                <span> Add to Favourites</span>
              </button>
            </div>
          </li>
        ))}
    </ul>
    </div>

  );
};

export default SearchResults;
