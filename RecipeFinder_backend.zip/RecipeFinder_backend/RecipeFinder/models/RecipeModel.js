const mongoose = require("mongoose");

const RecipeSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: [false],
    },
    description: {
      type: String,
      required: [false],
    },
    image: {
      type: String,
      required: [false],
    },
    recipeYield: {
      type: String,
      required: [false],
    },
    cookTime: {
      type: String,
      required: [false],
    },
    prepTime: {
      type: String,
      required: [false],
    },

    isFavourite: {
      type: Boolean,
      required: [false],
    },
    ingredients: [
      {
        type: String,
        required: [false],
      },
    ],
  },
  {
    timestamps: true,
  }
);
const Recipes = mongoose.model("recipes-10", RecipeSchema);
module.exports = Recipes;
