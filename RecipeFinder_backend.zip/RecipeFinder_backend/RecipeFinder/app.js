const fs=require('fs')
const express=require('express');
const cors = require('cors');
const path = require('path');


const ObjectId = require('mongodb').ObjectId;; 



const mongoose=require('mongoose')
const Recipe=require('./models/RecipeModel')
const app=express()
const data_string=fs.readFileSync('./public/recipes.json',"utf-8")
app.use(cors());


app.use(express.json())





const url="mongodb+srv://admin:group_project10@nodedb.80dff6m.mongodb.net/RecipeFinder?retryWrites=true&w=majority";
const products=(()=>{
   for(let i=0;i<1;i++)
   {
   }
})
products()
console.log();
mongoose.connect("mongodb+srv://admin:group_project10@nodedb.80dff6m.mongodb.net/RecipeFinder?retryWrites=true&w=majority").then(
   ()=>console.log("Connected to Db Successfully")).catch(()=>console.log("unable to connect Db"))
   let addAllRecipes=[]
   let data=JSON.parse(data_string);
   for(let i=0;i<data.length-5;i++)
   {
      data[i]={...data[i],isFavourite:false}

      addAllRecipes.push(data[i])


   }


   app.post('/api/addAllRecipes',async(req,res)=>{
      
       await Recipe.deleteMany({})
         console.log(addAllRecipes.length+" Documents going to be inserted");

         console.log("inserting to database")
                const AllRecipes=  await Recipe.insertMany(addAllRecipes);
                res.set('content-type','application/json')

                res.status(201).send(`${AllRecipes.length} Recipes inserted into Database successfully `);
                     




      


     
      


      




      
   })


   app.post('/api/addRecipe',async(req,res)=>{
 
      const AllRecipes=await Recipe.create(req.body)
      const  totalRecordsIndb=await Recipe.find({})

      res.status(201).json(totalRecordsIndb)

   
      


   })

   app.get('/findRecipe',async(req,res)=>{
      console.log(req.query.recipe);
      const {recipe}=req.query
const searchResult=await Recipe.find({
   $or:[
      {
         name:{'$regex' : recipe, '$options' : 'i'}
      }
      ,{
         description:{'$regex' : recipe, '$options' : 'i'}
      },
      {
         ingredients:{'$regex' : recipe, '$options' : 'i'}


      }
   ]})
   console.log("search results are"+searchResult)



      res.status(200).json(searchResult)

   })
   app.get('/fetchAllRecipe',async(req,res)=>{
      const data=await Recipe.find({})
      res.status(200).json(data)

   })
   app.get('/deleteAllRecipe',async(req,res)=>{
      await Recipe.deleteMany({})
      res.status(200).send("Recipes Deleted Successfully")





   })
   app.get('/api/fetchRecipesCount',async(req,res)=>{
      const count=await Recipe.countDocuments();
      res.status(200).send(`${count} `)
   })
   app.post('/api/updateFavouriteRecipe/:id',async(req,res)=>{
      const {id}=req.params
      console.log(id)
      const {isFavourite}=await Recipe.findOne({_id: new ObjectId(id)},{isFavourite:1})
      console.log(isFavourite)
      const data =await Recipe.updateOne({_id:new ObjectId(id)},{$set:{isFavourite:!isFavourite}})
      res.send("status Updated in a Recipe")
   })
   app.use((req, res, next) => {
      if (/(.ico|.js|.css|.jpg|.png|.map)$/i.test(req.path)) {
          next();
      } else {
          res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
          res.header('Expires', '-1');
          res.header('Pragma', 'no-cache');
          res.sendFile(path.join(__dirname, 'public','build', 'index.html'));
      }
   });
   app.use(express.static(path.join(__dirname,'public','build')));
   

   app.listen(8000,'0.0.0.0',()=>console.log(`port running on server 8000`))




